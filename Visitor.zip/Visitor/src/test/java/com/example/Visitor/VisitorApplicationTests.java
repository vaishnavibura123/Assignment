package com.example.Visitor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisitorApplicationTests {

	@Test
	void contextLoads() {
	}

}
